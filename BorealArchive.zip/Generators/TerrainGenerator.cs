using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[System.Serializable]
public struct TerrainType
{
    public string name;
    public float height;
}

public class TerrainGenerator : MonoBehaviour
{
    public IWorld World;

    public int seed;

    public float scale;
    public int octaves;
    [Range(0,1)]
    public float persistence;
    public float lacunarity;

    public TerrainType[] regions;

    public Vector2 offset = new Vector2(0,0);

    public bool autoUpdate;

    void OnStart()
    {
        World = gameObject.GetComponent<WorldController>().World;
    }

    public void GenerateTerrain()
    {
        if (World == null)
        {
            Debug.Log("No world found");
            return;
        }

        int width = World.Width;
        int height = World.Height;

        float[,] reliefMap = Noise.GenerateNoiseMap(width, height, seed, scale, octaves, persistence, lacunarity, offset);

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Tile t = World.GetTileAt(x, y);
                t.Altitude = reliefMap[x, y];

                for (int i = 0; i < regions.Length; i++)
                {
                    if (t.Altitude <= regions[i].height)
                    {
                        t.Type = regions[i].name;
                        break;
                    }
                }

            }
        }
    }

    public void RandomizeTerrain()
    {
        seed = new System.Random().Next(-100000, 100000);
        GenerateTerrain();
    }

    void OnValidate()
    {
        if (lacunarity < 1)
        {
            lacunarity = 1;
        }
        if (octaves < 0)
        {
            octaves = 0;
        }
    }

}

