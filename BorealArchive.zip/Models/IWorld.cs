﻿using System;

public interface IWorld
{
    int Width { get; }
    int Height { get; }

    Tile GetTileAt(int x, int y);
    void PlaceFurnitureOnTile(string furnitureType, Tile t);
    void RegisterFurnitureChangedCallback(Action<FurnitureObject> callback);
    void RegisterTileChangedCallback(Action<Tile> callback);
    void RemoveFurnituresFromTile(Tile t);
    void UnregisterFurnitureChangedCallback(Action<FurnitureObject> callback);
    void UnregisterTileChangedCallback(Action<Tile> callback);
}
