using UnityEngine;

public class WorldController : MonoBehaviour
{
    public int width;
    public int height;

    public static WorldController Instance { get; protected set; }

    public World World { get; protected set; }

    // Start is called before the first frame update
    void Awake()
    {
        // initialise random number generator
        if (Instance != null)
        {
            Debug.Log("There should never be two instances of WorldController");
        }

        Instance = this;

        World = CreateWorld(width, height);
    }

    public World CreateWorld(int width, int height)
    {
        World newWorld = new World(width, height);
        //Center camera

        Vector3 worldCenter = new Vector3((float)width / 2f, (float)height / 2f, Camera.main.transform.position.z);
        //Debug.Log(worldCenter);
        Camera.main.transform.position = worldCenter;

        //trigger terrain generation by terrainGeneratorController, using FindObject
        TerrainGenerator terrainGenerator = gameObject.GetComponent<TerrainGenerator>();

        if (terrainGenerator == null)
        {
            terrainGenerator = gameObject.AddComponent<TerrainGenerator>();
        }

        terrainGenerator.World = newWorld;
        terrainGenerator.GenerateTerrain();


        return newWorld;
    }

    public Tile GetTileAt(Vector3 worldPoint)
    {
        int x = Mathf.FloorToInt(worldPoint.x + 0.5f);
        int y = Mathf.FloorToInt(worldPoint.y + 0.5f);

        Tile tile = World.GetTileAt(x, y);
        if (tile == null) {
            Debug.Log("No tile at point " + worldPoint);
            return null;
        }
        else return tile;

    }

}
