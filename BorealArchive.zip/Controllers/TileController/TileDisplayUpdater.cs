using System;
using System.Collections.Generic;
using UnityEngine;

public class TileDisplayUpdater : MonoBehaviour
{

    System.Random rng;

    Dictionary<Tile, GameObject> tileGameObjectMap;

    Dictionary<string, List<Sprite>> tileSpritesMap;

    // TheWorld rendering parameters
    public float tileShaderNoiseSigma = 0.01f;
    public float tileShaderDepth = 0.8f;

    // Start is called before the first frame update
    void Start()
    {
        // initialise random number generator
        rng = new System.Random();
        tileSpritesMap = SpritesMap.Load("Tile");

    }

    public void OnTileChanged(GameObject tile_go, Tile tile_data)
    {
        if (tile_go == null) {
            Debug.Log("No tile GameObject provided");
            return;
        }
        if (tile_data == null) {
            Debug.Log("No tile data provided");
            return;
        }

        ApplySpriteToTile(tile_go, tile_data);
        RandomlyRotateSprite(tile_go); //TODO: when more sophisticated sprites are available, this will become redundant?
        ShadeSpriteTile(tile_go, tile_data);

    }

    void ApplySpriteToTile(GameObject tile_go, Tile tile_data)
    {
        string tileType = tile_data.Type;

        if (tileSpritesMap.ContainsKey(tileType) == false)
        {
            Debug.Log("SpriteController.ApplyRandomSpriteToTile -- no sprites found for tile type " + tileType);
            return;
        }

        if (tile_go.GetComponent<SpriteRenderer>() == null)
        {
            tile_go.AddComponent<SpriteRenderer>();
        }

        List<Sprite> sprites = tileSpritesMap[tileType];
        Sprite randomSprite = sprites[rng.Next(sprites.Count)];
        tile_go.GetComponent<SpriteRenderer>().sprite = randomSprite;

    }

    void RandomlyRotateSprite(GameObject go)
    {
        Vector3 randomSpriteRotation = new Vector3(0.0f, 0.0f, 90.0f * rng.Next(3));
        go.GetComponent<SpriteRenderer>().transform.Rotate(randomSpriteRotation, Space.Self);
    }

    void ShadeSpriteTile(GameObject tile_go, Tile tile_data)
    {
        // adjust renderer brightness according to tile altitude
        float intensity = 1 + tileShaderDepth * (tile_data.Altitude - 1);
        intensity += Noise.NextGaussian(rng, 0, tileShaderNoiseSigma);

        Color shaderColor = new Color(intensity, intensity, intensity, 1.0f);

        tile_go.GetComponent<SpriteRenderer>().material.SetColor("_Color", shaderColor);
    }

}
