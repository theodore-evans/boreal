using System.Collections.Generic;
using UnityEngine;

public class TileController : MonoBehaviour
{

    public World World;
    public static TileController Instance { get; protected set; }  // TODO: change to non-static dependency injection

    TileDisplayUpdater displayUpdater;
    TilePropertyUpdater propertyUpdater;

    public Dictionary<Tile, GameObject> TileGameObjectMap { get; protected set; }

    // Start is called before the first frame update
    void Start()
    {
        if (Instance != null) {
            Debug.Log("There should never be two instances of TileController");
        }

        Instance = this;

        //TODO add checks / pass these in a different way?
        displayUpdater = gameObject.GetComponent<TileDisplayUpdater>(); 
        propertyUpdater = gameObject.GetComponent<TilePropertyUpdater>();

        if (World == null) {
            Debug.Log("No World linked, requesting world instance from WorldController");
            World retrievedWorld = WorldController.Instance.GetComponent<WorldController>().World;
            if (retrievedWorld == null) {
                Debug.Log("No World instance found in WorldController");
                return;
            }
            else { World = retrievedWorld; }
        }

        //Create GameObjects to display for each tile
        TileGameObjectMap = new Dictionary<Tile, GameObject>();

        for (int x = 0; x < World.Width; x++)
        {
            for (int y = 0; y < World.Height; y++)
            {
                // creates a new go and adds it to the scene
                GameObject tile_go = new GameObject();

                // add tile gameobject components
                tile_go.AddComponent<BoxCollider>();

                // gets the Tile for this point in the TheWorld
                Tile tile_data = World.GetTileAt(x, y);

                // add mapping of game object -> tile data to the dictionary
                TileGameObjectMap.Add(tile_data, tile_go);

                // sets the tile_go position
                tile_go.name = "Tile_" + x + "_" + y;
                tile_go.transform.position = new Vector3(tile_data.X, tile_data.Y);
                tile_go.transform.SetParent(this.gameObject.transform, true);

                OnTileChanged(tile_data);
            }
        }

        World.RegisterTileChangedCallback(OnTileChanged);

    }

    public GameObject GetTileGameObject(Tile tile_data)
    {
        if (TileGameObjectMap.ContainsKey(tile_data) == false)
        {
            Debug.LogError($"GetTileGameObject: No key found in tileGameObjectMap for tile at [{tile_data.X}, {tile_data.Y}] ");
            return null;
        }

        GameObject tile_go = TileGameObjectMap[tile_data];

        if (tile_go == null)
        {
            Debug.LogError($"GetTileGameObject: No GameObject found for tile at [{tile_data.X}, {tile_data.Y}] ");
            return null;
        }

        return tile_go;
    }

    void OnTileChanged(Tile tile_data)
    {
        GameObject tile_go = GetTileGameObject(tile_data);

        displayUpdater.OnTileChanged(tile_go, tile_data);
        propertyUpdater.OnTileChanged(tile_go, tile_data);
    }
}
