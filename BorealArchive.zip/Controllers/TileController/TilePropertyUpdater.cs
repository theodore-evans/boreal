﻿using System;
using UnityEngine;


public class TilePropertyUpdater : MonoBehaviour
{

    public LayerMask WaterMask;
    public LayerMask WalkableMask;

    // Use this for initialization
    void Start()
    {

    }

    public void OnTileChanged(GameObject tile_go, Tile tile_data)
    {
        if (tile_data.Type == "Water") {
            tile_go.layer = WaterMask;
        }
        else tile_go.layer = WalkableMask; 
    }

    // Update is called once per frame
    void Update()
    {

    }
}
