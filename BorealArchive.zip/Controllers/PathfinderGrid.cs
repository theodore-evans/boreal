﻿using UnityEngine;
using System.Collections;
using System;

public class PathfinderGrid : MonoBehaviour
{
    public LayerMask unwalkableMask;
    public Vector2 gridWorldSize;
    public float nodeRadius;
    Node[,] grid;

    float nodeDiameter;
    int gridSizeX, gridSizeY;
    Vector3 worldBottomLeft;

    public int nearestNeighbours;
    [Range(0,64)]
    public float highlightX;
    [Range(0, 64)]
    public float highlightY;

    // Use this for initialization
    void Start()
    {
        Vector2 gridWorldSize = new Vector2(
            WorldController.Instance.World.Width,
            WorldController.Instance.World.Height
        );

        nodeDiameter = nodeRadius * 2;
        gridSizeX = Mathf.RoundToInt(gridWorldSize.x / nodeDiameter);
        gridSizeY = Mathf.RoundToInt(gridWorldSize.y / nodeDiameter);
        worldBottomLeft = TileController.Instance.transform.position; // TODO: tie this to tilecontroller position in a better way

        CreateGrid();
    }

    void CreateGrid()
    {
        grid = new Node[gridSizeX, gridSizeY];
        for (int x = 0; x < gridSizeX; x++)
        {
            for (int y = 0; y < gridSizeY; y++)
            {
                Vector3 worldPoint = worldBottomLeft + Vector3.right * (x * nodeDiameter + nodeRadius) + Vector3.up * (y * nodeDiameter + nodeRadius);
                bool walkable = !Physics.CheckSphere(worldPoint, nodeRadius, unwalkableMask);
                grid[x, y] = new Node(walkable, worldPoint);

                // TODO register a callback with tile to get updated if they change (eg. become walkable/unwalkable)
            }
        }
    }

    void UpdateGridAtWorldPoint(Vector3 worldPoint)
    {

    }

    public Node[] NodesAtWorldPoint(Vector3 worldPosition, int range)
    {
        float percentX = worldPosition.x / gridWorldSize.x;
        float percentY = worldPosition.y / gridWorldSize.y;
        percentX = Mathf.Clamp01(percentX);
        percentY = Mathf.Clamp01(percentY);

        int x = Mathf.RoundToInt((gridSizeX - 1) * percentX);
        int y = Mathf.RoundToInt((gridSizeY - 1) * percentY);

        int[][] nearestNeighborIndices = MooreNeighborhoodIndices(x, y, range);
        int nNearestNeighbors = nearestNeighborIndices.Length;
        Node[] nodes = new Node[nNearestNeighbors];

        for (int i = 0; i < nNearestNeighbors; i++) {
            nodes[i] = grid[ nearestNeighborIndices[i][0], nearestNeighborIndices[i][1] ];
        }
        return nodes;
    }

    public Node NodeAtWorldPoint(Vector3 worldPosition)
    {
        return NodesAtWorldPoint(worldPosition, 0)[0];
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireCube(transform.position, new Vector3(gridWorldSize.x, gridWorldSize.y, 1));

        if (grid != null)
        {
            foreach (Node n in grid)
            {
                Color color = (n.walkable) ? Color.white : Color.red;
                color.a = 0.4f;
                Gizmos.color = color;
                Gizmos.DrawCube(n.worldPoint, Vector3.one * (nodeDiameter - .1f));
            }

            Node[] nodesAtOrigin = NodesAtWorldPoint(new Vector3(highlightX, highlightY), nearestNeighbours);
            foreach (Node n in nodesAtOrigin) {
                Gizmos.color = Color.green;
                Gizmos.DrawCube(n.worldPoint, Vector3.one * (nodeDiameter - .1f));
            }
        }
    }

    //public Node NodeFromWorldPoint(Vector3 worldPoint)
    //{

    //}

    int[][] MooreNeighborhoodIndices (int centreX, int centreY, int range)
    {
        int sideLength = 1 + 2 * range;
        int neighborhoodSize = sideLength * sideLength;
        int currentNeighbor = 0;

        int[][] neighbourIndices = new int[neighborhoodSize][];
        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                neighbourIndices[currentNeighbor] = new int[] { centreX + x, centreY + y };
                currentNeighbor++;
            }
        }
        return neighbourIndices;
    }
}

public class Node
{
    public bool walkable;
    public Vector3 worldPoint;

    public Node(bool walkable, Vector3 worldPoint)
    {
        this.walkable = walkable;
        this.worldPoint = worldPoint;
    }

}